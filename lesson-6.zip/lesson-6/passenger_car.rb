class PassengerCar
end
