class CargoCar 
end
